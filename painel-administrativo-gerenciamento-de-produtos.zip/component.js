// <stdin>
import React, { useState, useEffect } from "https://esm.sh/react@18.2.0";
var AdminPanel = () => {
  const [products, setProducts] = useState([]);
  const [editingProduct, setEditingProduct] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [activeTab, setActiveTab] = useState("basic");
  const [formData, setFormData] = useState({
    name: "",
    price: "",
    description: "",
    category: "camisas",
    images: [],
    uploadedImages: [],
    stock: 0,
    rating: 4.5,
    reviews: 0,
    tags: [],
    featured: false,
    reference: "",
    variants: {
      colors: [],
      sizes: []
    },
    briefingQuestions: []
  });
  useEffect(() => {
    try {
      const savedProducts = localStorage.getItem("products");
      if (savedProducts) {
        const parsedProducts = JSON.parse(savedProducts);
        setProducts(Array.isArray(parsedProducts) ? parsedProducts : []);
      }
    } catch (error) {
      console.error("Erro ao carregar produtos:", error);
      setProducts([]);
    }
  }, []);
  const saveToLocalStorage = (productsToSave) => {
    try {
      const dataToSave = JSON.stringify(productsToSave);
      localStorage.setItem("products", dataToSave);
      localStorage.setItem("siteProducts", dataToSave);
      console.log("\u2705 Produtos salvos no localStorage");
      return true;
    } catch (error) {
      console.error("\u274C Erro ao salvar no localStorage:", error);
      return false;
    }
  };
  const resetForm = () => {
    setFormData({
      name: "",
      price: "",
      description: "",
      category: "camisas",
      images: [],
      uploadedImages: [],
      stock: 0,
      rating: 4.5,
      reviews: 0,
      tags: [],
      featured: false,
      reference: "",
      variants: {
        colors: [],
        sizes: []
      },
      briefingQuestions: []
    });
    setEditingProduct(null);
    setShowForm(false);
    setActiveTab("basic");
  };
  const addProduct = () => {
    try {
      console.log("\u{1F4DD} Iniciando adi\xE7\xE3o/edi\xE7\xE3o de produto...");
      if (!formData.name || formData.name.trim().length < 3) {
        alert("\u274C Nome do produto deve ter pelo menos 3 caracteres!");
        return;
      }
      if (!formData.price || formData.price.trim() === "") {
        alert("\u274C Pre\xE7o \xE9 obrigat\xF3rio!");
        return;
      }
      const priceValue = formData.price.replace(/[^\d,]/g, "").replace(",", ".");
      const numericPrice = parseFloat(priceValue) || 0;
      if (numericPrice <= 0) {
        alert("\u274C Pre\xE7o deve ser maior que zero!");
        return;
      }
      const allImages = [
        ...(formData.images || []).filter((img) => img && img.trim()),
        ...(formData.uploadedImages || []).filter((img) => img && img.trim())
      ];
      const formattedData = {
        ...formData,
        name: formData.name.trim(),
        price: formData.price.startsWith("R$") ? formData.price : `R$ ${formData.price}`,
        numericPrice,
        images: allImages,
        uploadedImages: formData.uploadedImages || [],
        briefingQuestions: (formData.briefingQuestions || []).filter((q) => q && q.trim() !== ""),
        description: (formData.description || "").trim(),
        category: formData.category || "camisas",
        stock: Math.max(0, parseInt(formData.stock) || 0),
        rating: Math.min(5, Math.max(0, parseFloat(formData.rating) || 4.5)),
        reviews: Math.max(0, parseInt(formData.reviews) || 0),
        tags: (formData.tags || []).filter((tag) => tag && tag.trim()),
        featured: Boolean(formData.featured),
        reference: formData.reference || `REF-${Date.now()}`,
        variants: {
          colors: (formData.variants?.colors || []).filter((color) => color && color.trim()),
          sizes: (formData.variants?.sizes || []).filter((size) => size && size.trim())
        },
        createdAt: editingProduct ? editingProduct.createdAt : (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      };
      const duplicateName = products.find(
        (p) => p.name.toLowerCase() === formattedData.name.toLowerCase() && (!editingProduct || p.id !== editingProduct.id)
      );
      if (duplicateName) {
        const confirm2 = window.confirm(`\u26A0\uFE0F J\xE1 existe um produto com o nome "${formattedData.name}". Deseja continuar mesmo assim?`);
        if (!confirm2) return;
      }
      let updatedProducts;
      if (editingProduct) {
        updatedProducts = products.map(
          (p) => p.id === editingProduct.id ? { ...formattedData, id: editingProduct.id } : p
        );
      } else {
        const newProduct = {
          ...formattedData,
          id: `product-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
        };
        updatedProducts = [...products || [], newProduct];
      }
      setProducts(updatedProducts);
      const saveSuccess = saveToLocalStorage(updatedProducts);
      if (saveSuccess) {
        setTimeout(() => {
          try {
            window.dispatchEvent(new StorageEvent("storage", {
              key: "products",
              newValue: JSON.stringify(updatedProducts),
              oldValue: null,
              url: window.location.href,
              storageArea: localStorage
            }));
            window.dispatchEvent(new StorageEvent("storage", {
              key: "siteProducts",
              newValue: JSON.stringify(updatedProducts),
              oldValue: null,
              url: window.location.href,
              storageArea: localStorage
            }));
            window.dispatchEvent(new CustomEvent("productDataChanged", {
              detail: { products: updatedProducts, source: "admin-panel" }
            }));
            console.log("\u{1F504} Eventos de sincroniza\xE7\xE3o disparados");
          } catch (eventError) {
            console.warn("\u26A0\uFE0F Erro ao disparar evento de sincroniza\xE7\xE3o:", eventError);
          }
        }, 100);
      }
      const successMessage = `\u{1F389} SUCESSO! 
      
Produto "${formattedData.name}" foi ${editingProduct ? "atualizado" : "cadastrado"} com sucesso!

\u2705 Dados salvos localmente
\u2705 Site atualizado automaticamente
\u2705 ${allImages.length} imagem(s) anexada(s)

O formul\xE1rio ser\xE1 fechado em 3 segundos...`;
      alert(successMessage);
      setTimeout(() => {
        resetForm();
      }, 3e3);
    } catch (error) {
      console.error("\u{1F4A5} ERRO ao salvar produto:", error);
      alert(`\u274C ERRO INESPERADO! 

Detalhes: ${error.message || "Erro desconhecido"}

Dados N\xC3O foram salvos. Tente novamente.`);
    }
  };
  const editProduct = (product) => {
    setFormData(product);
    setEditingProduct(product);
    setShowForm(true);
    setActiveTab("basic");
  };
  const deleteProduct = (id) => {
    if (confirm("Tem certeza que deseja deletar este produto?")) {
      const updatedProducts = products.filter((p) => p.id !== id);
      setProducts(updatedProducts);
      saveToLocalStorage(updatedProducts);
      setTimeout(() => {
        window.dispatchEvent(new StorageEvent("storage", {
          key: "products",
          newValue: JSON.stringify(updatedProducts),
          url: window.location.href
        }));
      }, 100);
    }
  };
  const updateSite = () => {
    try {
      const saveSuccess = saveToLocalStorage(products);
      if (saveSuccess) {
        window.dispatchEvent(new StorageEvent("storage", {
          key: "products",
          newValue: JSON.stringify(products),
          url: window.location.href
        }));
        alert(`\u2705 Site atualizado com ${products.length} produtos!`);
      } else {
        alert("\u26A0\uFE0F Houve problemas na atualiza\xE7\xE3o. Tente novamente.");
      }
    } catch (error) {
      alert(`\u274C ERRO ao atualizar site: ${error.message}`);
    }
  };
  const addTag = (tag) => {
    if (tag && !formData.tags.includes(tag)) {
      setFormData((prev) => ({
        ...prev,
        tags: [...prev.tags, tag]
      }));
    }
  };
  const removeTag = (index) => {
    setFormData((prev) => ({
      ...prev,
      tags: prev.tags.filter((_, i) => i !== index)
    }));
  };
  const handleImageUpload = (event) => {
    const files = Array.from(event.target.files);
    files.forEach((file) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        setFormData((prev) => ({
          ...prev,
          uploadedImages: [...prev.uploadedImages, e.target.result]
        }));
      };
      reader.readAsDataURL(file);
    });
  };
  return /* @__PURE__ */ React.createElement("div", { className: "min-h-screen bg-gray-50 p-4" }, /* @__PURE__ */ React.createElement("div", { className: "max-w-7xl mx-auto" }, /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded-lg shadow-sm p-6 mb-6" }, /* @__PURE__ */ React.createElement("div", { className: "flex justify-between items-center mb-4" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h1", { className: "text-3xl font-bold text-gray-900" }, "\u{1F3EA} Painel Administrativo"), /* @__PURE__ */ React.createElement("p", { className: "text-gray-600" }, "Gerencie produtos da sua loja virtual")), /* @__PURE__ */ React.createElement("div", { className: "flex gap-3" }, /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => {
        console.log("\u{1F9EA} Testando sincroniza\xE7\xE3o...");
        const testProduct = {
          id: `test-${Date.now()}`,
          name: `Produto Teste ${(/* @__PURE__ */ new Date()).toLocaleTimeString()}`,
          price: "R$ 99,90",
          category: "camisas",
          images: ["assets/teste.png?prompt=Produto%20de%20teste"],
          stock: 10,
          featured: true
        };
        const testProducts = [...products, testProduct];
        setProducts(testProducts);
        const success = saveToLocalStorage(testProducts);
        if (success) {
          setTimeout(() => {
            window.dispatchEvent(new StorageEvent("storage", {
              key: "products",
              newValue: JSON.stringify(testProducts),
              url: window.location.href
            }));
            alert("\u{1F9EA} Produto teste adicionado! Verifique o site.");
          }, 100);
        }
      },
      className: "bg-orange-600 hover:bg-orange-700 text-white px-4 py-3 rounded-lg font-medium transition-colors shadow-sm text-sm",
      title: "Adicionar produto teste para verificar sincroniza\xE7\xE3o"
    },
    "\u{1F9EA} Teste Sync"
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: updateSite,
      className: "bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-medium transition-colors shadow-sm"
    },
    "\u{1F504} Atualizar Site"
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setShowForm(true),
      className: "bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-medium transition-colors shadow-sm"
    },
    "\u2795 Novo Produto"
  ))), /* @__PURE__ */ React.createElement("div", { className: "bg-blue-50 border border-blue-200 rounded-lg p-4" }, /* @__PURE__ */ React.createElement("div", { className: "flex items-center gap-3" }, /* @__PURE__ */ React.createElement("div", { className: "bg-blue-100 p-2 rounded-full" }, /* @__PURE__ */ React.createElement("span", { className: "text-blue-600 text-xl" }, "\u{1F4CA}")), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h3", { className: "font-semibold text-blue-900" }, "Status do Sistema"), /* @__PURE__ */ React.createElement("p", { className: "text-blue-700 text-sm" }, "\u{1F4E6} ", products.length, " produto(s) cadastrado(s) \u2022 \u{1F4BE} Salvos localmente \u2022 \u{1F504} Sincroniza\xE7\xE3o autom\xE1tica ativa"))))), !showForm && /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded-lg shadow-sm" }, /* @__PURE__ */ React.createElement("div", { className: "p-6 border-b" }, /* @__PURE__ */ React.createElement("h2", { className: "text-xl font-semibold text-gray-900" }, "\u{1F4CB} Produtos Cadastrados")), /* @__PURE__ */ React.createElement("div", { className: "p-6" }, products.length === 0 ? /* @__PURE__ */ React.createElement("div", { className: "text-center py-12" }, /* @__PURE__ */ React.createElement("div", { className: "text-gray-400 text-6xl mb-4" }, "\u{1F4E6}"), /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-medium text-gray-900 mb-2" }, "Nenhum produto cadastrado"), /* @__PURE__ */ React.createElement("p", { className: "text-gray-500 mb-6" }, "Comece adicionando seu primeiro produto"), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setShowForm(true),
      className: "bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-medium transition-colors"
    },
    "\u2795 Adicionar Primeiro Produto"
  )) : /* @__PURE__ */ React.createElement("div", { className: "grid gap-4" }, products.map((product) => /* @__PURE__ */ React.createElement("div", { key: product.id, className: "border rounded-lg p-4 hover:bg-gray-50 transition-colors" }, /* @__PURE__ */ React.createElement("div", { className: "flex justify-between items-start" }, /* @__PURE__ */ React.createElement("div", { className: "flex gap-4" }, /* @__PURE__ */ React.createElement("div", { className: "w-16 h-16 bg-gray-200 rounded-lg flex items-center justify-center" }, product.images && product.images.length > 0 ? /* @__PURE__ */ React.createElement(
    "img",
    {
      src: product.images[0],
      alt: product.name,
      className: "w-full h-full object-cover rounded-lg"
    }
  ) : /* @__PURE__ */ React.createElement("span", { className: "text-gray-400 text-2xl" }, "\u{1F4F7}")), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h3", { className: "font-semibold text-gray-900" }, product.name), /* @__PURE__ */ React.createElement("p", { className: "text-green-600 font-medium" }, product.price), /* @__PURE__ */ React.createElement("p", { className: "text-sm text-gray-500 capitalize" }, product.category, " \u2022 Estoque: ", product.stock), product.featured && /* @__PURE__ */ React.createElement("span", { className: "inline-block bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded-full mt-1" }, "\u2B50 Destaque"))), /* @__PURE__ */ React.createElement("div", { className: "flex gap-2" }, /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => editProduct(product),
      className: "bg-blue-100 hover:bg-blue-200 text-blue-700 px-3 py-2 rounded text-sm transition-colors"
    },
    "\u270F\uFE0F Editar"
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => deleteProduct(product.id),
      className: "bg-red-100 hover:bg-red-200 text-red-700 px-3 py-2 rounded text-sm transition-colors"
    },
    "\u{1F5D1}\uFE0F Excluir"
  )))))))), showForm && /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded-lg shadow-sm" }, /* @__PURE__ */ React.createElement("div", { className: "p-6 border-b" }, /* @__PURE__ */ React.createElement("div", { className: "flex justify-between items-center" }, /* @__PURE__ */ React.createElement("h2", { className: "text-xl font-semibold text-gray-900" }, editingProduct ? "\u270F\uFE0F Editar Produto" : "\u2795 Novo Produto"), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: resetForm,
      className: "text-gray-400 hover:text-gray-600 transition-colors"
    },
    "\u2715"
  ))), /* @__PURE__ */ React.createElement("div", { className: "border-b" }, /* @__PURE__ */ React.createElement("nav", { className: "flex space-x-8 px-6" }, [
    { id: "basic", label: "\u{1F4DD} B\xE1sico", icon: "\u{1F4DD}" },
    { id: "images", label: "\u{1F4F8} Imagens", icon: "\u{1F4F8}" },
    { id: "details", label: "\u{1F50D} Detalhes", icon: "\u{1F50D}" },
    { id: "briefing", label: "\u{1F4CB} Briefing", icon: "\u{1F4CB}" }
  ].map((tab) => /* @__PURE__ */ React.createElement(
    "button",
    {
      key: tab.id,
      onClick: () => setActiveTab(tab.id),
      className: `py-4 px-2 border-b-2 font-medium text-sm transition-colors ${activeTab === tab.id ? "border-blue-500 text-blue-600" : "border-transparent text-gray-500 hover:text-gray-700"}`
    },
    tab.icon,
    " ",
    tab.label
  )))), /* @__PURE__ */ React.createElement("div", { className: "p-6" }, activeTab === "basic" && /* @__PURE__ */ React.createElement("div", { className: "space-y-6" }, /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-700 mb-2" }, "\u{1F4DD} Nome do Produto *"), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "text",
      value: formData.name,
      onChange: (e) => setFormData((prev) => ({ ...prev, name: e.target.value })),
      className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500",
      placeholder: "Ex: Camisa Polo Masculina"
    }
  )), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-700 mb-2" }, "\u{1F4B0} Pre\xE7o *"), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "text",
      value: formData.price,
      onChange: (e) => setFormData((prev) => ({ ...prev, price: e.target.value })),
      className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500",
      placeholder: "Ex: R$ 89,90"
    }
  )), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-700 mb-2" }, "\u{1F3F7}\uFE0F Categoria"), /* @__PURE__ */ React.createElement(
    "select",
    {
      value: formData.category,
      onChange: (e) => setFormData((prev) => ({ ...prev, category: e.target.value })),
      className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
    },
    /* @__PURE__ */ React.createElement("option", { value: "camisas" }, "\u{1F454} Camisas"),
    /* @__PURE__ */ React.createElement("option", { value: "calcas" }, "\u{1F456} Cal\xE7as"),
    /* @__PURE__ */ React.createElement("option", { value: "vestidos" }, "\u{1F457} Vestidos"),
    /* @__PURE__ */ React.createElement("option", { value: "sapatos" }, "\u{1F460} Sapatos"),
    /* @__PURE__ */ React.createElement("option", { value: "acessorios" }, "\u{1F45C} Acess\xF3rios"),
    /* @__PURE__ */ React.createElement("option", { value: "esportes" }, "\u26BD Esportes"),
    /* @__PURE__ */ React.createElement("option", { value: "infantil" }, "\u{1F476} Infantil")
  )), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-700 mb-2" }, "\u{1F4E6} Estoque"), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "number",
      value: formData.stock,
      onChange: (e) => setFormData((prev) => ({ ...prev, stock: parseInt(e.target.value) || 0 })),
      className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500",
      min: "0"
    }
  ))), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-700 mb-2" }, "\u{1F4C4} Descri\xE7\xE3o"), /* @__PURE__ */ React.createElement(
    "textarea",
    {
      value: formData.description,
      onChange: (e) => setFormData((prev) => ({ ...prev, description: e.target.value })),
      rows: 4,
      className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500",
      placeholder: "Descreva o produto..."
    }
  )), /* @__PURE__ */ React.createElement("div", { className: "flex items-center" }, /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "checkbox",
      id: "featured",
      checked: formData.featured,
      onChange: (e) => setFormData((prev) => ({ ...prev, featured: e.target.checked })),
      className: "h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
    }
  ), /* @__PURE__ */ React.createElement("label", { htmlFor: "featured", className: "ml-2 block text-sm text-gray-900" }, "\u2B50 Produto em destaque"))), activeTab === "images" && /* @__PURE__ */ React.createElement("div", { className: "space-y-6" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-700 mb-2" }, "\u{1F5BC}\uFE0F URLs de Imagens"), /* @__PURE__ */ React.createElement("div", { className: "space-y-2" }, formData.images.map((image, index) => /* @__PURE__ */ React.createElement("div", { key: index, className: "flex gap-2" }, /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "url",
      value: image,
      onChange: (e) => {
        const newImages = [...formData.images];
        newImages[index] = e.target.value;
        setFormData((prev) => ({ ...prev, images: newImages }));
      },
      className: "flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500",
      placeholder: "https://..."
    }
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => {
        const newImages = formData.images.filter((_, i) => i !== index);
        setFormData((prev) => ({ ...prev, images: newImages }));
      },
      className: "bg-red-100 hover:bg-red-200 text-red-700 px-3 py-2 rounded transition-colors"
    },
    "\u{1F5D1}\uFE0F"
  ))), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setFormData((prev) => ({ ...prev, images: [...prev.images, ""] })),
      className: "bg-blue-100 hover:bg-blue-200 text-blue-700 px-4 py-2 rounded transition-colors"
    },
    "\u2795 Adicionar URL"
  ))), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-700 mb-2" }, "\u{1F4E4} Upload de Imagens"), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "file",
      multiple: true,
      accept: "image/*",
      onChange: handleImageUpload,
      className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
    }
  ), formData.uploadedImages.length > 0 && /* @__PURE__ */ React.createElement("div", { className: "mt-4 grid grid-cols-2 md:grid-cols-4 gap-4" }, formData.uploadedImages.map((image, index) => /* @__PURE__ */ React.createElement("div", { key: index, className: "relative" }, /* @__PURE__ */ React.createElement(
    "img",
    {
      src: image,
      alt: `Upload ${index + 1}`,
      className: "w-full h-24 object-cover rounded-lg border"
    }
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => {
        const newImages = formData.uploadedImages.filter((_, i) => i !== index);
        setFormData((prev) => ({ ...prev, uploadedImages: newImages }));
      },
      className: "absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs hover:bg-red-600 transition-colors"
    },
    "\u2715"
  )))))), activeTab === "details" && /* @__PURE__ */ React.createElement("div", { className: "space-y-6" }, /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-700 mb-2" }, "\u2B50 Avalia\xE7\xE3o (1-5)"), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "number",
      value: formData.rating,
      onChange: (e) => setFormData((prev) => ({ ...prev, rating: parseFloat(e.target.value) || 0 })),
      className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500",
      min: "1",
      max: "5",
      step: "0.1"
    }
  )), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-700 mb-2" }, "\u{1F4AC} N\xFAmero de Avalia\xE7\xF5es"), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "number",
      value: formData.reviews,
      onChange: (e) => setFormData((prev) => ({ ...prev, reviews: parseInt(e.target.value) || 0 })),
      className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500",
      min: "0"
    }
  ))), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-700 mb-2" }, "\u{1F4E6} Refer\xEAncia do Produto"), /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "text",
      value: formData.reference,
      onChange: (e) => setFormData((prev) => ({ ...prev, reference: e.target.value })),
      className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500",
      placeholder: "Ex: REF-001"
    }
  )), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-700 mb-2" }, "\u{1F3F7}\uFE0F Tags"), /* @__PURE__ */ React.createElement("div", { className: "flex flex-wrap gap-2 mb-2" }, formData.tags.map((tag, index) => /* @__PURE__ */ React.createElement(
    "span",
    {
      key: index,
      className: "bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm flex items-center gap-1"
    },
    tag,
    /* @__PURE__ */ React.createElement(
      "button",
      {
        onClick: () => removeTag(index),
        className: "text-blue-600 hover:text-blue-800"
      },
      "\u2715"
    )
  ))), /* @__PURE__ */ React.createElement("div", { className: "flex gap-2" }, /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "text",
      placeholder: "Nova tag...",
      className: "flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500",
      onKeyPress: (e) => {
        if (e.key === "Enter") {
          addTag(e.target.value.trim());
          e.target.value = "";
        }
      }
    }
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: (e) => {
        const input = e.target.previousElementSibling;
        addTag(input.value.trim());
        input.value = "";
      },
      className: "bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded transition-colors"
    },
    "\u2795"
  ))), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-700 mb-2" }, "\u{1F3A8} Cores Dispon\xEDveis"), /* @__PURE__ */ React.createElement("div", { className: "space-y-2" }, (formData.variants?.colors || []).map((color, index) => /* @__PURE__ */ React.createElement("div", { key: index, className: "flex gap-2" }, /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "text",
      value: color,
      onChange: (e) => {
        const newColors = [...formData.variants.colors];
        newColors[index] = e.target.value;
        setFormData((prev) => ({
          ...prev,
          variants: { ...prev.variants, colors: newColors }
        }));
      },
      className: "flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500",
      placeholder: "Ex: Azul"
    }
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => {
        const newColors = formData.variants.colors.filter((_, i) => i !== index);
        setFormData((prev) => ({
          ...prev,
          variants: { ...prev.variants, colors: newColors }
        }));
      },
      className: "bg-red-100 hover:bg-red-200 text-red-700 px-3 py-2 rounded transition-colors"
    },
    "\u{1F5D1}\uFE0F"
  ))), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setFormData((prev) => ({
        ...prev,
        variants: { ...prev.variants, colors: [...prev.variants.colors, ""] }
      })),
      className: "bg-blue-100 hover:bg-blue-200 text-blue-700 px-4 py-2 rounded transition-colors"
    },
    "\u2795 Adicionar Cor"
  ))), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-700 mb-2" }, "\u{1F4CF} Tamanhos Dispon\xEDveis"), /* @__PURE__ */ React.createElement("div", { className: "space-y-2" }, (formData.variants?.sizes || []).map((size, index) => /* @__PURE__ */ React.createElement("div", { key: index, className: "flex gap-2" }, /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "text",
      value: size,
      onChange: (e) => {
        const newSizes = [...formData.variants.sizes];
        newSizes[index] = e.target.value;
        setFormData((prev) => ({
          ...prev,
          variants: { ...prev.variants, sizes: newSizes }
        }));
      },
      className: "flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500",
      placeholder: "Ex: M"
    }
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => {
        const newSizes = formData.variants.sizes.filter((_, i) => i !== index);
        setFormData((prev) => ({
          ...prev,
          variants: { ...prev.variants, sizes: newSizes }
        }));
      },
      className: "bg-red-100 hover:bg-red-200 text-red-700 px-3 py-2 rounded transition-colors"
    },
    "\u{1F5D1}\uFE0F"
  ))), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setFormData((prev) => ({
        ...prev,
        variants: { ...prev.variants, sizes: [...prev.variants.sizes, ""] }
      })),
      className: "bg-blue-100 hover:bg-blue-200 text-blue-700 px-4 py-2 rounded transition-colors"
    },
    "\u2795 Adicionar Tamanho"
  ))))), activeTab === "briefing" && /* @__PURE__ */ React.createElement("div", { className: "space-y-6" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("label", { className: "block text-sm font-medium text-gray-700 mb-2" }, "\u2753 Perguntas do Briefing"), /* @__PURE__ */ React.createElement("p", { className: "text-sm text-gray-500 mb-4" }, "Adicione perguntas que o cliente deve responder ao personalizar o produto"), /* @__PURE__ */ React.createElement("div", { className: "space-y-3" }, (formData.briefingQuestions || []).map((question, index) => /* @__PURE__ */ React.createElement("div", { key: index, className: "flex gap-2" }, /* @__PURE__ */ React.createElement(
    "input",
    {
      type: "text",
      value: question,
      onChange: (e) => {
        const newQuestions = [...formData.briefingQuestions];
        newQuestions[index] = e.target.value;
        setFormData((prev) => ({ ...prev, briefingQuestions: newQuestions }));
      },
      className: "flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500",
      placeholder: "Ex: Qual texto deseja na estampa?"
    }
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => {
        const newQuestions = formData.briefingQuestions.filter((_, i) => i !== index);
        setFormData((prev) => ({ ...prev, briefingQuestions: newQuestions }));
      },
      className: "bg-red-100 hover:bg-red-200 text-red-700 px-3 py-2 rounded transition-colors"
    },
    "\u{1F5D1}\uFE0F"
  ))), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setFormData((prev) => ({
        ...prev,
        briefingQuestions: [...prev.briefingQuestions, ""]
      })),
      className: "bg-blue-100 hover:bg-blue-200 text-blue-700 px-4 py-2 rounded transition-colors"
    },
    "\u2795 Adicionar Pergunta"
  )), formData.briefingQuestions.length > 0 && /* @__PURE__ */ React.createElement("div", { className: "mt-6 p-4 bg-gray-50 border border-gray-200 rounded-lg" }, /* @__PURE__ */ React.createElement("h4", { className: "font-medium text-gray-900 mb-2" }, "\u{1F4CB} Preview do Briefing:"), /* @__PURE__ */ React.createElement("ul", { className: "space-y-1" }, formData.briefingQuestions.filter((q) => q.trim()).map((question, index) => /* @__PURE__ */ React.createElement("li", { key: index, className: "text-sm text-gray-700" }, index + 1, ". ", question)))))), /* @__PURE__ */ React.createElement("div", { className: "flex justify-end gap-3 pt-6 border-t" }, /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: resetForm,
      className: "bg-gray-200 hover:bg-gray-300 text-gray-700 px-6 py-3 rounded-lg font-medium transition-colors"
    },
    "\u274C Cancelar"
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: addProduct,
      className: "bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-medium transition-colors"
    },
    editingProduct ? "\u270F\uFE0F Atualizar Produto" : "\u{1F4BE} Salvar Produto"
  ))))));
};
var stdin_default = AdminPanel;
export {
  stdin_default as default
};
